# ATFAA-Release
ATFAA - Advanced Terminal For All Applications By Debug, Antis, InfoCube and Shell
Version: 0.0.2
